#!/bin/bash
python3 ./upload.py
sudo killall -9 openvpn