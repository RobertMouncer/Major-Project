#!/bin/bash
sudo pigpiod
python3 Data_logger.py
